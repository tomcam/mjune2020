# Metabuzz is a no-configuration static site generator that builds full web pages
